module Connection where

--подключение к интернету