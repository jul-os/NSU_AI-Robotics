#include "decls.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


void echo_0(State* state) {
    printf("ECHO:\n");
}

void echo_1(State* state, char* arg0) {
    printf("ECHO: %s\n", arg0);
}

void echo_2(State* state, char* arg0, char* arg1) {
    printf("ECHO: %s|%s\n", arg0, arg1);
}

void echo_3(State* state, char* arg0, char* arg1, char* arg2) {
    printf("ECHO: %s|%s|%s\n", arg0, arg1, arg2);
}

void print_1(State* state, char* idx) {
    int i = atoi(idx);
    printf("%s\n", state->regs[i]);
}

void printregs_0(State* state) {
    int i;
    for (i = 0; i < 256; i++) {
        if (state->regs[i] != NULL) {
            printf("%d = %s\n", i, state->regs[i]);
        }
    }
}

void store_2(State* state, char* idx, char* what) {
    int i = atoi(idx);
    if (state->regs[i] != NULL) {
        free(state->regs[i]);
    }
    state->regs[i] = (char*)malloc(strlen(what) + 1);
    strcpy(state->regs[i], what);
}

void copy_2(State* state, char* dst, char* src) {
    int i = atoi(dst);
    int j = atoi(src);
    if (i == j) {
        return;
    }
    if (state->regs[i] != NULL) {
        free(state->regs[i]);
    }
    state->regs[i] = (char*)malloc(strlen(state->regs[j]) + 1);
    strcpy(state->regs[i], state->regs[j]);
}

void clear_1(State* state, char* idx) {
    int i = atoi(idx);
    if (state->regs[i] != NULL) {
        free(state->regs[i]);
        state->regs[i] = NULL;
    }
}
