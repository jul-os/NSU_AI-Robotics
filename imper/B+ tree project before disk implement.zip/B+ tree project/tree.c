#include <stdio.h>
#include <stdlib.h>
#include "tree.h"
#include "disk.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>

void *tree_memory = NULL;
size_t tree_memory_size = 0;
int tree_fd = -1;


//fixme возможно не понадобиться после дописания disk.h
void bptree_init(int t, int data_fd, int log_fd)
{
    tree_fd = data_fd;
    tree_memory_size = INITIAL_TREE_SIZE;

    // Проверим, что файл имеет нужный размер. Если нет — увеличим.
    struct stat st;
    if (fstat(tree_fd, &st) == -1)
    {
        perror("fstat failed");
        return;
    }
    if (st.st_size < tree_memory_size)
    {
        if (ftruncate(tree_fd, tree_memory_size) == -1)
        {
            perror("ftruncate failed");
            return;
        }
    }
    tree_memory = mmap(NULL, tree_memory_size, PROT_READ | PROT_WRITE, MAP_SHARED, tree_fd, 0);
    if (tree_memory == MAP_FAILED)
    {
        perror("mmap failed");
        return;
    }

    // Теперь можно обращаться к tree_memory как к массиву байт
    // Например:
    // int* root_block = (int*)(tree_memory + 0);
    // *root_block = 42;
}

Node *create_node(int t, bool is_leaf)
{
    Node *new_node = (Node *)malloc(sizeof(Node));
    new_node->keys = (int *)malloc((2 * t - 1) * sizeof(int));
    // Выделяем память для pointers
    if (is_leaf)
    {
        // Для листа - указатели на данные (records)
        new_node->data_pointers = (void **)malloc((2 * t - 1) * sizeof(void *));
        new_node->children = NULL; // Листья не имеют дочерних узлов
    }
    else
    {
        // Для внутреннего узла - указатели на дочерние узлы
        new_node->data_pointers = NULL; // Не используем для данных
        // каждый узел содержит не более 2t-1 ключей
        // внутренний узел содержит не более 2t дочерних узлов
        new_node->children = (Node **)malloc(2 * t * sizeof(Node *));
    }
    new_node->t = t;
    new_node->n = 0;
    new_node->leaf = is_leaf;
    if (new_node->leaf)
    {
        // TODO их потом обновлять при добавлении и удалении
        // TODO points to some data
        new_node->prev = new_node;
        new_node->next = new_node;
        // fixme хотя на самом деле я хз на что оно должно указывать
    }
    else
    {
        new_node->prev = NULL;
        new_node->next = NULL;
    }
    return new_node;
}

BTree *create_tree(int t)
{
    BTree *tree = (BTree *)malloc(sizeof(BTree));
    tree->root = create_node(t, true);
    tree->t = t;
    return tree;
}

void *find(int val, BTree *tree)
{
    // start with head node
    Node *C = tree->root;
    while (!C->leaf)
    {
        int i = 0;
        while (i < C->n && val <= C->keys[i])
        {
            i++;
        }
        if (i == C->n)
        {
            C = C->children[C->n];
        }
        else if (val == C->keys[i])
        {
            C = C->children[i + 1];
        }
        else
        {
            C = C->children[i]; // val < C->keys[i]
        }
    }
    // now C is a leaf
    for (int i = 0; i < C->n; i++)
    {
        if (C->keys[i] == val)
        {
            // TODO функция которая достает с диска
            return C->data_pointers[i]; // fixme тип функции другой скорее всего
        }
    }
    return NULL;
}

// то же самое что обычный find но возвращает лист С а не инфу
Node *find_leaf(int val, BTree *tree)
{
    // start with head node
    Node *C = tree->root;
    while (!C->leaf)
    {
        int i = 0;
        while (i < C->n && val <= C->keys[i])
        {
            i++;
        }
        if (i == C->n)
        {
            C = C->children[C->n];
        }
        else if (val == C->keys[i])
        {
            C = C->children[i + 1];
        }
        else
        {
            C = C->children[i]; // val < C->keys[i]
        }
    }
    // now C is a leaf
    for (int i = 0; i < C->n; i++)
    {
        if (C->keys[i] == val)
        {
            return C;
        }
    }
    return NULL;
}

Node *find_parent(BTree *tree, Node *child)
{
    if (tree->root == child)
    {
        return NULL;
    }

    Node *current = tree->root;
    Node *parent = NULL;
    while (!current->leaf && current != child)
    {
        parent = current;
        int i = 0;
        while (i < current->n && current->keys[0] <= current->keys[i])
        {
            i++;
        }
        if (i == current->n)
        {
            current = current->children[current->n];
        }
        else if (current->keys[0] == current->keys[i])
        {
            current = current->children[i + 1];
        }
        else
        {
            current = current->children[i]; // val < C->keys[i]
        }
    }
    return (current == child) ? parent : NULL;
}

// TODO check
void range_query(BTree *tree, int min_k, int max_k)
{
    if (!tree || !tree->root)
    {
        return;
    }
    Node *start_node = find_leaf(min_k, tree);
    if (!start_node)
    {
        return;
    }
    int i = 0;
    // пропускаем ключи коорые меньше min_k
    while (i < start_node->n && start_node->keys[i] < min_k)
    {
        i++;
    }
    while (start_node != NULL)
    {
        for (; i < start_node->n; i++)
        {
            if (start_node->keys[i] > max_k)
            {
                return;
            }
            // else were still in the right diaposon
            // TODO take from mem
        }

        start_node = start_node->next;
        i = 0;
    }
}

void insert_into_leaf(Node *L, int K, void *P)
{
    // find where to insert
    int insert_pos = 0;
    while (insert_pos < L->n && K > L->keys[insert_pos])
    {
        insert_pos++;
    }
    // move other elements to the right
    // пояснение: мы в insert уже проверили что лист не будет переполнен
    for (int i = L->n; i > insert_pos; i--)
    {
        L->keys[i] = L->keys[i - 1];
        L->data_pointers[i] = L->data_pointers[i - 1];
    }
    // insert the new key and pointer
    L->keys[insert_pos] = K;
    L->data_pointers[insert_pos] = P;
    L->n++;
    // оказалось что вообще-то указатель из родителя в лист не обязан указывать на первый элемент листа поэтому типа все в этой функции
}

void insert_into_parent(BTree *tree, Node *N, int K_prime, Node *N_prime)
{
    if (tree->root == N)
    {
        Node *new_root = create_node(tree->t, false);
        new_root->keys[0] = K_prime;
        new_root->children[0] = N;
        new_root->children[1] = N_prime;
        new_root->n = 1;
        tree->root = new_root;
        return;
    }
    Node *parent = find_parent(tree, N);
    if (parent->n < 2 * tree->t - 1)
    {
        int insert_pos = 0;
        while (insert_pos <= parent->n && parent->children[insert_pos] != N)
        {
            insert_pos++;
        }
        insert_pos++; // inserting after N
        // move to the right
        for (int i = parent->n; i >= insert_pos; i--)
        {
            parent->keys[i] = parent->keys[i - 1];
        }
        for (int i = parent->n + 1; i > insert_pos; i--)
        {
            parent->children[i] = parent->children[i - 1];
        }
        // insert K_prime & N_prime
        parent->keys[insert_pos - 1] = K_prime;
        parent->children[insert_pos] = N_prime;
        parent->n++;
    }
    // else parent doesnt have enough dpace
    else
    {
        int total_keys = parent->n + 1;
        int *temp_keys = malloc(total_keys * sizeof(int));
        Node **temp_pointers = malloc((total_keys + 1) * sizeof(Node *));

        // Копируем существующие данные во временный массив
        int i = 0, j = 0;
        while (i <= parent->n && parent->children[i] != N)
        {
            temp_pointers[j] = parent->children[i];
            if (i < parent->n)
            {
                temp_keys[j] = parent->keys[i];
            }
            i++;
            j++;
        }
        // Вставляем K_prime и N_prime после N
        temp_pointers[j] = N;
        temp_keys[j] = K_prime;
        j++;
        temp_pointers[j] = N_prime;
        i++;

        // Копируем оставшиеся элементы
        while (i <= parent->n)
        {
            temp_pointers[j] = parent->children[i];
            if (i < parent->n)
            {
                temp_keys[j] = parent->keys[i];
            }
            i++;
            j++;
        }

        // Определяем точку разделения
        int split_pos = total_keys / 2;
        int K_double_prime = temp_keys[split_pos];

        Node *P_prime = create_node(tree->t, false);
        parent->n = 0;
        for (i = 0; i < split_pos; i++)
        {
            parent->children[i] = temp_pointers[i];
            parent->keys[i] = temp_keys[i];
            parent->n++;
        }
        parent->children[i] = temp_pointers[i];

        P_prime->n = 0;
        for (i = split_pos + 1, j = 0; i < total_keys; i++, j++)
        {
            P_prime->children[j] = temp_pointers[i];
            P_prime->keys[j] = temp_keys[i];
            P_prime->n++;
        }
        P_prime->children[j] = temp_pointers[i];
        free(temp_keys);
        free(temp_pointers);

        insert_into_parent(tree, parent, K_double_prime, P_prime);
    }
}

// assignment тут короче указатель непонятно на что, когда работу с диском прибавим надо будет посмотреть что здесь должно быть
void insert(BTree *tree, int K, void *P)
{
    // if tree is empty
    if (tree->root == NULL || tree->root->n == 0)
    // task can the second thing happen?
    {
        Node *L = create_node(tree->t, true);
        // leaf L which is also the root
        L->keys[0] = K;
        L->n = 1;
        tree->root = L;
        return;
    }
    // find node in which insert
    Node *L = find_leaf(K, tree);

    // if node has some space
    if (L->n < 2 * tree->t - 1)
    {
        insert_into_leaf(L, K, P);
    }
    else
    {
        // EXPLODE THE NODE
        Node *L_prime = create_node(tree->t, true);
        // temp malloc to store keys and pointers
        int total_keys = L->n + 1;
        int *temp_keys = malloc(total_keys * sizeof(int));
        // fixme void pointers or Node pointers????
        void **temp_pointers = malloc(total_keys * sizeof(void *));
        // copy keys find place for new key
        int i = 0, j = 0;
        while (i < L->n && K > L->keys[i])
        {
            temp_keys[j] = L->keys[i];
            temp_pointers[j] = L->data_pointers[i];
            i++;
            j++;
        }
        // insert new key
        temp_keys[j] = K;
        temp_pointers[j] = P;
        j++;
        // copy keys that are left
        while (i < L->n)
        {
            temp_keys[j] = L->keys[i];
            temp_pointers[j] = L->data_pointers[i];
            i++;
            j++;
        }
        // find split point
        int split_pos = total_keys / 2;
        int K_prime = temp_keys[split_pos];
        // TODO тут где-то запись на диск еще ))))
        //  update L and L_prime
        L->n = split_pos;
        for (i = 0; i < split_pos; i++)
        {
            L->keys[i] = temp_keys[i];
            L->data_pointers[i] = temp_pointers[i];
        }
        L_prime->n = total_keys - split_pos;
        for (i = split_pos; i < total_keys; i++)
        {
            L_prime->keys[i - split_pos] = temp_keys[i];
            L_prime->data_pointers[i - split_pos] = temp_pointers[i];
        }
        // update relations between leaves
        L_prime->next = L->next;
        if (L->next != NULL)
        {
            L->next->prev = L_prime;
        }
        L->next = L_prime;
        L_prime->prev = L;
        free(temp_keys);
        free(temp_pointers);

        insert_into_parent(tree, L, K_prime, L_prime);
    }
}

// находит индекс (позицию) узла child среди дочерних узлов его родителя parent
int find_child_index(Node *parent, Node *child)
{
    int index = 0;
    while (index <= parent->n && parent->children[index != child])
    {
        index++;
    }
    return index;
}

void remove_key_and_pointer(Node *N, int K)
{
    // task а оно может вообще быть не листом?
    int i = 0;
    while (i < N->n && N->keys[i] != K)
    {
        i++;
    }

    // if leaf, shilf keys and data pointers
    if (N->leaf)
    {
        for (; i < N->n - 1; i++)
        {
            N->keys[i] = N->keys[i + 1];
            N->data_pointers[i] = N->data_pointers[i + 1];
        }
    }
    // if interanal node, shift keys and children pointers
    else
    {
        for (; i < N->n - 1; i++)
        {
            N->keys[i] = N->keys[i + 1];
            N->children[i] = N->children[i + 1];
        }
    }
    N->n--;
}

// merge two nodes together
void coalesce_nodes(Node *N, Node *N_prime, Node *parent, int K_prime, BTree *tree)
{
    if (!N->leaf)
    {
        // последний ключ левого узла теперь ключ который разделял левый и правый ключи в родительском узле
        N_prime->keys[N_prime->n] = K_prime;
        N_prime->n++;

        // copy from N to N_prime
        for (int i = 0; i < N->n; i++)
        {
            N_prime->keys[N_prime->n + i] = N->keys[i];
            N_prime->children[N_prime->n + i] = N->children[i];
        }
        N_prime->children[N_prime->n + N->n] = N->children[N->n];
        N_prime->n += N->n;
    }
    else
    {
        for (int i = 0; i < N->n; i++)
        {
            N_prime->keys[N_prime->n + i] = N->keys[i];
            N_prime->data_pointers[N_prime->n + i] = N->data_pointers[i];
        }
        N_prime->n += N->n;

        // Update leaf linked list
        N_prime->next = N->next;
        if (N->next != NULL)
        {
            N->next->prev = N_prime;
        }
        // N_prime-> prev и N_prime->prev->next обновлять не нужно
        // N_prime-> next = N->next
        // N->next->prev = N_prime
        // N->prev удалится при удалении узла ниже
    }
    delete_entry(parent, K_prime, N, tree);
    free(N->keys);
    if (N->leaf)
    {
        free(N->data_pointers);
    }
    else
    {
        free(N->children);
    }
    free(N);
}

void redistribute_nodes(Node *N, Node *N_prime, Node *parent, int K_prime, int N_index)
{
    // if N_prime is left to N
    if (N_index > 0 && parent->children[N_index - 1] == N_prime)
    {
        if (!N->leaf)
        {
            // Move the last child of N_prime to be the first child of N
            for (int i = N->n; i > 0; i--)
            {
                N->keys[i] = N->keys[i - 1];
                N->children[i + 1] = N->children[i];
            }
            N->children[1] = N->children[0];
            /*тут логика такая
            K_prime это ключ который стоит между узлами N_prime и N в родительском узле
            и мы хотим чтобы на место этого ключа в родительском узле встал нужный нам ключ из N_prime
            а K_prime из ролителя спускаем в N
            из N_prime при этом он как бы уходит
            */
            N->children[0] = N_prime->children[N_prime->n];
            N->keys[0] = K_prime;
            N->n++;

            // update key in parent
            parent->keys[N_index - 1] = N_prime->keys[N_prime->n - 1];
            N_prime->n--;
        }
        // else its a leaf
        else
        {
            // same but for keys
            for (int i = N->n; i > 0; i--)
            {
                N->keys[i] = N->keys[i - 1];
                N->data_pointers[i] = N->data_pointers[i - 1];
            }

            N->keys[0] = N_prime->keys[N_prime->n - 1];
            N->data_pointers[0] = N_prime->data_pointers[N_prime->n - 1];
            N->n++;

            // update key in parent
            parent->keys[N_index - 1] = N->keys[0];
            N_prime->n--;
        }
    }
    // else N_prime is right to N
    else
    {
        if (!N->leaf)
        {
            // move first child of N_prime to be last in N
            N->keys[N->n] = K_prime;
            N->children[N->n + 1] = N_prime->children[0];
            N->n++;

            // update key in parent
            parent->keys[N_index] = N_prime->keys[0];

            // Shift keys and children in N_prime
            for (int i = 0; i < N_prime->n - 1; i++)
            {
                N_prime->keys[i] = N_prime->keys[i + 1];
                N_prime->children[i] = N_prime->children[i + 1];
            }
            N_prime->children[N_prime->n - 1] = N_prime->children[N_prime->n];
            N_prime->n--;
        }
        else
        {
            // For leaf nodes
            // Move the first key of N_prime to be the last key of N
            N->keys[N->n] = N_prime->keys[0];
            N->data_pointers[N->n] = N_prime->data_pointers[0];
            N->n++;

            // Update parent's key
            parent->keys[N_index] = N_prime->keys[1];

            // Shift keys and data pointers in N_prime
            for (int i = 0; i < N_prime->n - 1; i++)
            {
                N_prime->keys[i] = N_prime->keys[i + 1];
                N_prime->data_pointers[i] = N_prime->data_pointers[i + 1];
            }
            N_prime->n--;
        }
    }
}

void delete_entry(Node *N, int K, void *P, BTree *tree)
{
    // remove key and pointers from the node
    remove_key_and_pointer(N, K);

    // if (N is the root and N has only one remaining child)
    // then make the child of N the new root of the tree and delete N
    if (N == tree->root && N->n == 0 && !N->leaf)
    {
        // в общем n = 0 и 1 ребенок это норм потому что кол-во детей = n + 1
        // но 1 ребенок может бть только у корня если что
        Node *new_root = N->children[0];
        free(N->keys);
        free(N->children);
        free(N);
        tree->root = new_root;
        return;
    }

    // if after deletion node has too few keys/pointers
    if (!N->leaf && N->n < tree->t - 1)
    {
        Node *parent = find_parent(tree, N);
        int N_index = find_child_index(parent, N);

        Node *left_sibling = (N_index > 0) ? parent->children[N_index - 1] : NULL;
        Node *right_sibling = (N_index < parent->n) ? parent->children[N_index + 1] : NULL;

        // try borrowing from the left sibling
        if (left_sibling && left_sibling->n > tree->t - 1)
        {
            redistribute_nodes(N, left_sibling, parent, parent->keys[N_index - 1], N_index);
        }
        // try borrowing from the right sibling
        else if (right_sibling && right_sibling->n > tree->t - 1)
        {
            redistribute_nodes(N, right_sibling, parent, parent->keys[N_index], N_index);
        }
        // if cant borrow merge
        else
        {
            if (left_sibling)
            {
                coalesce_nodes(N, left_sibling, parent, parent->keys[N_index - 1], tree);
            }
            else if (right_sibling)
            {
                coalesce_nodes(right_sibling, N, parent, parent->keys[N_index], tree);
            }
        }
    }
    // now if N doesnt have too few keys/pointers
    else if (N->leaf && N->n < tree->t - 1)
    {
        Node *parent = find_parent(tree, N);
        if (parent)
        {
            int N_index = find_child_index(parent, N);

            // Find left and right siblings
            Node *left_sibling = (N_index > 0) ? parent->children[N_index - 1] : NULL;
            Node *right_sibling = (N_index < parent->n) ? parent->children[N_index + 1] : NULL;

            // Try to borrow from left sibling
            if (left_sibling && left_sibling->n > tree->t - 1)
            {
                redistribute_nodes(N, left_sibling, parent, parent->keys[N_index - 1], N_index);
            }
            // Try to borrow from right sibling
            else if (right_sibling && right_sibling->n > tree->t - 1)
            {
                redistribute_nodes(N, right_sibling, parent, parent->keys[N_index], N_index);
            }
            // If can't borrow, merge with a sibling
            else
            {
                if (left_sibling)
                {
                    coalesce_nodes(N, left_sibling, parent, parent->keys[N_index - 1], tree);
                }
                else if (right_sibling)
                {
                    coalesce_nodes(right_sibling, N, parent, parent->keys[N_index], tree);
                }
            }
        }
    }
}

void delete(int key, void *point, BTree *tree)
{
    Node *leaf = find_leaf(key, tree);
    delete_entry(leaf, key, point, tree);
}

int main()
{
    BTree *tre = create_tree(3);
    insert(tre, 10, 20);
    return 0;
}